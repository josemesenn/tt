# mkdir.sh
#!/bin/bash
mkdir -p twitter_likes/app
touch twitter_likes/app/main.py
touch twitter_likes/app/requirements.txt
touch twitter_likes/app/Dockerfile
touch twitter_likes/.env
